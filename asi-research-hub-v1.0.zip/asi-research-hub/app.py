from flask import Flask, request, jsonify
from flask_cors import CORS
from flask_jwt_extended import JWTManager, create_access_token, jwt_required, get_jwt_identity
import os
from config import Config
from database import init_db, get_db
from auth import AuthService
from search import SearchService
from utils import validate_email, validate_password, allowed_file
import json

app = Flask(__name__)
app.config.from_object(Config)

# Enable CORS for WordPress embedding
CORS(app, origins=[Config.FRONTEND_URL])

# JWT setup
jwt = JWTManager(app)

# Initialize database on first run
if not os.path.exists(Config.DATABASE_PATH):
    init_db()

# ============================================================================
# AUTHENTICATION ROUTES
# ============================================================================

@app.route('/api/register', methods=['POST'])
def register():
    """User registration endpoint"""
    data = request.get_json()
    
    # Validate input
    required_fields = ['email', 'password', 'first_name', 'last_name', 'tier', 'reason']
    for field in required_fields:
        if field not in data:
            return jsonify({'error': f'Missing field: {field}'}), 400
    
    # Validate email
    if not validate_email(data['email']):
        return jsonify({'error': 'Invalid email format'}), 400
    
    # Validate password
    if not validate_password(data['password']):
        return jsonify({'error': 'Password must be at least 8 characters'}), 400
    
    # Validate tier
    if data['tier'] not in ['student', 'researcher', 'institutional']:
        return jsonify({'error': 'Invalid tier'}), 400
    
    # Create user
    result = AuthService.create_user(
        email=data['email'],
        password=data['password'],
        first_name=data['first_name'],
        last_name=data['last_name'],
        tier=data['tier'],
        reason=data['reason']
    )
    
    if result['success']:
        return jsonify({
            'message': 'Registration successful! Please check your email to verify your account.',
            'user_id': result['user_id']
        }), 201
    else:
        return jsonify({'error': result['error']}), 400

@app.route('/api/verify', methods=['POST'])
def verify_email():
    """Email verification endpoint"""
    data = request.get_json()
    token = data.get('token')
    
    if not token:
        return jsonify({'error': 'Missing verification token'}), 400
    
    result = AuthService.verify_email(token)
    
    if result['success']:
        return jsonify({'message': 'Email verified successfully! You can now log in.'}), 200
    else:
        return jsonify({'error': result['error']}), 400

@app.route('/api/login', methods=['POST'])
def login():
    """User login endpoint"""
    data = request.get_json()
    
    email = data.get('email')
    password = data.get('password')
    
    if not email or not password:
        return jsonify({'error': 'Missing email or password'}), 400
    
    result = AuthService.login(email, password)
    
    if result['success']:
        # Create JWT token
        access_token = create_access_token(identity=result['user']['id'])
        
        return jsonify({
            'access_token': access_token,
            'user': result['user']
        }), 200
    else:
        return jsonify({'error': result['error']}), 401

@app.route('/api/me', methods=['GET'])
@jwt_required()
def get_current_user():
    """Get current user info"""
    user_id = get_jwt_identity()
    
    with get_db() as conn:
        cursor = conn.cursor()
        cursor.execute("""
            SELECT id, email, first_name, last_name, tier, created_at 
            FROM users WHERE id = ?
        """, (user_id,))
        user = cursor.fetchone()
    
    if user:
        return jsonify(dict(user)), 200
    else:
        return jsonify({'error': 'User not found'}), 404

# ============================================================================
# SEARCH ROUTES
# ============================================================================

@app.route('/api/search', methods=['POST'])
@jwt_required()
def search():
    """Unified search endpoint"""
    user_id = get_jwt_identity()
    data = request.get_json()
    
    query = data.get('query', '').strip()
    sources = data.get('sources', ['internal'])  # Default to internal only
    tags = data.get('tags', [])
    year_from = data.get('year_from')
    asip_funded_only = data.get('asip_funded_only', False)
    
    if not query:
        return jsonify({'error': 'Query cannot be empty'}), 400
    
    # Perform search
    result = SearchService.unified_search(
        query=query,
        sources=sources,
        tags=tags,
        year_from=year_from,
        asip_funded_only=asip_funded_only,
        user_id=user_id
    )
    
    return jsonify({
        'papers': [paper.to_dict() for paper in result.papers],
        'total_count': result.total_count,
        'query': result.query,
        'sources_used': result.sources_used,
        'execution_time': round(result.execution_time, 2)
    }), 200

@app.route('/api/papers/featured', methods=['GET'])
def get_featured_papers():
    """Get ASIP-funded research highlights"""
    with get_db() as conn:
        cursor = conn.cursor()
        cursor.execute("""
            SELECT * FROM papers 
            WHERE asip_funded = TRUE 
            ORDER BY year DESC, citation_count DESC 
            LIMIT 10
        """)
        rows = cursor.fetchall()
    
    from models import Paper
    papers = [Paper.from_db_row(row).to_dict() for row in rows]
    return jsonify({'papers': papers}), 200

@app.route('/api/papers/<int:paper_id>', methods=['GET'])
@jwt_required()
def get_paper(paper_id):
    """Get single paper details"""
    with get_db() as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM papers WHERE id = ?", (paper_id,))
        row = cursor.fetchone()
    
    if row:
        from models import Paper
        paper = Paper.from_db_row(row)
        return jsonify(paper.to_dict()), 200
    else:
        return jsonify({'error': 'Paper not found'}), 404

# ============================================================================
# BOOKMARK ROUTES
# ============================================================================

@app.route('/api/bookmarks', methods=['GET'])
@jwt_required()
def get_bookmarks():
    """Get user's bookmarked papers"""
    user_id = get_jwt_identity()
    
    with get_db() as conn:
        cursor = conn.cursor()
        cursor.execute("""
            SELECT p.*, b.notes, b.created_at as bookmarked_at
            FROM papers p
            JOIN user_bookmarks b ON p.id = b.paper_id
            WHERE b.user_id = ?
            ORDER BY b.created_at DESC
        """, (user_id,))
        rows = cursor.fetchall()
    
    from models import Paper
    papers = [Paper.from_db_row(row).to_dict() for row in rows]
    return jsonify({'bookmarks': papers}), 200

@app.route('/api/bookmarks', methods=['POST'])
@jwt_required()
def add_bookmark():
    """Add paper to bookmarks"""
    user_id = get_jwt_identity()
    data = request.get_json()
    
    paper_id = data.get('paper_id')
    notes = data.get('notes', '')
    
    if not paper_id:
        return jsonify({'error': 'Missing paper_id'}), 400
    
    try:
        with get_db() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                INSERT INTO user_bookmarks (user_id, paper_id, notes)
                VALUES (?, ?, ?)
            """, (user_id, paper_id, notes))
        
        return jsonify({'message': 'Bookmark added successfully'}), 201
    except Exception as e:
        return jsonify({'error': 'Bookmark already exists or paper not found'}), 400

@app.route('/api/bookmarks/<int:paper_id>', methods=['DELETE'])
@jwt_required()
def remove_bookmark(paper_id):
    """Remove paper from bookmarks"""
    user_id = get_jwt_identity()
    
    with get_db() as conn:
        cursor = conn.cursor()
        cursor.execute("""
            DELETE FROM user_bookmarks 
            WHERE user_id = ? AND paper_id = ?
        """, (user_id, paper_id))
    
    return jsonify({'message': 'Bookmark removed successfully'}), 200

# ============================================================================
# ANALYTICS ROUTES (Admin only)
# ============================================================================

@app.route('/api/analytics/searches', methods=['GET'])
@jwt_required()
def get_search_analytics():
    """Get search analytics (simplified for V1)"""
    user_id = get_jwt_identity()
    
    # TODO: Add admin check in V2
    
    with get_db() as conn:
        cursor = conn.cursor()
        
        # Top searches
        cursor.execute("""
            SELECT query, COUNT(*) as count 
            FROM search_logs 
            WHERE created_at >= date('now', '-30 days')
            GROUP BY query 
            ORDER BY count DESC 
            LIMIT 10
        """)
        top_searches = [dict(row) for row in cursor.fetchall()]
        
        # Searches by user tier
        cursor.execute("""
            SELECT u.tier, COUNT(*) as count 
            FROM search_logs s 
            JOIN users u ON s.user_id = u.id 
            WHERE s.created_at >= date('now', '-30 days')
            GROUP BY u.tier
        """)
        by_tier = [dict(row) for row in cursor.fetchall()]
        
        # Total searches
        cursor.execute("""
            SELECT COUNT(*) as total 
            FROM search_logs 
            WHERE created_at >= date('now', '-30 days')
        """)
        total = cursor.fetchone()['total']
    
    return jsonify({
        'top_searches': top_searches,
        'by_tier': by_tier,
        'total_searches': total
    }), 200

# ============================================================================
# UTILITY ROUTES
# ============================================================================

@app.route('/api/tags', methods=['GET'])
def get_tags():
    """Get list of valid tags"""
    return jsonify({'tags': Config.VALID_TAGS}), 200

@app.route('/api/health', methods=['GET'])
def health_check():
    """Health check endpoint"""
    return jsonify({'status': 'healthy', 'version': '1.0.0'}), 200

@app.route('/')
def index():
    """Serve test interface"""
    return app.send_static_file('index.html')

# ============================================================================
# ERROR HANDLERS
# ============================================================================

@app.errorhandler(404)
def not_found(error):
    return jsonify({'error': 'Endpoint not found'}), 404

@app.errorhandler(500)
def internal_error(error):
    return jsonify({'error': 'Internal server error'}), 500

# ============================================================================
# RUN APP
# ============================================================================

if __name__ == '__main__':
    # Ensure upload directory exists
    os.makedirs(Config.UPLOAD_FOLDER, exist_ok=True)
    
    # Run app
    port = int(os.environ.get('PORT', 5000))
    app.run(host='0.0.0.0', port=port, debug=True)
