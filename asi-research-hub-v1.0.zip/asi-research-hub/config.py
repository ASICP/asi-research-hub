import os
from datetime import timedelta

class Config:
    # Flask
    SECRET_KEY = os.environ.get('SECRET_KEY') or 'dev-secret-key-change-in-production'
    
    # JWT
    JWT_SECRET_KEY = os.environ.get('JWT_SECRET_KEY') or 'jwt-secret-key-change-in-production'
    JWT_ACCESS_TOKEN_EXPIRES = timedelta(hours=24)
    
    # Database
    DATABASE_PATH = 'asi_research_hub.db'
    
    # Email (SendGrid)
    SENDGRID_API_KEY = os.environ.get('SENDGRID_API_KEY')
    FROM_EMAIL = 'noreply@asi2.org'
    
    # File Upload
    UPLOAD_FOLDER = 'static/uploads'
    MAX_CONTENT_LENGTH = 50 * 1024 * 1024  # 50MB max file size
    ALLOWED_EXTENSIONS = {'pdf'}
    
    # API Rate Limits
    PERPLEXITY_MONTHLY_LIMIT = 500
    PERPLEXITY_API_KEY = os.environ.get('PERPLEXITY_API_KEY')
    
    # Frontend URL (for CORS)
    FRONTEND_URL = os.environ.get('FRONTEND_URL') or 'https://asi2.org'
    
    # Tags
    VALID_TAGS = [
        'alignment_fundamentals',
        'interpretability',
        'robustness',
        'governance',
        'technical_safety',
        'ethics',
        'red_teaming'
    ]
