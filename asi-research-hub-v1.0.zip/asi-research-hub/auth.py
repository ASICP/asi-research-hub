import bcrypt
import secrets
from datetime import datetime
from database import get_db
from sendgrid import SendGridAPIClient
from sendgrid.helpers.mail import Mail
from config import Config

class AuthService:
    
    @staticmethod
    def hash_password(password: str) -> str:
        """Hash password using bcrypt"""
        return bcrypt.hashpw(password.encode('utf-8'), bcrypt.gensalt()).decode('utf-8')
    
    @staticmethod
    def verify_password(password: str, password_hash: str) -> bool:
        """Verify password against hash"""
        return bcrypt.checkpw(password.encode('utf-8'), password_hash.encode('utf-8'))
    
    @staticmethod
    def generate_verification_token() -> str:
        """Generate secure random token"""
        return secrets.token_urlsafe(32)
    
    @staticmethod
    def create_user(email: str, password: str, first_name: str, 
                   last_name: str, tier: str, reason: str) -> dict:
        """Create new user account"""
        password_hash = AuthService.hash_password(password)
        verification_token = AuthService.generate_verification_token()
        
        with get_db() as conn:
            cursor = conn.cursor()
            
            # Check if email already exists
            cursor.execute("SELECT id FROM users WHERE email = ?", (email,))
            if cursor.fetchone():
                return {'success': False, 'error': 'Email already registered'}
            
            # Insert user
            cursor.execute("""
                INSERT INTO users (email, password_hash, first_name, last_name, 
                                 tier, reason, verification_token)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            """, (email, password_hash, first_name, last_name, tier, reason, verification_token))
            
            user_id = cursor.lastrowid
        
        # Send verification email
        AuthService.send_verification_email(email, first_name, verification_token)
        
        return {'success': True, 'user_id': user_id}
    
    @staticmethod
    def send_verification_email(email: str, first_name: str, token: str):
        """Send email verification link"""
        verification_url = f"{Config.FRONTEND_URL}/verify?token={token}"
        
        message = Mail(
            from_email=Config.FROM_EMAIL,
            to_emails=email,
            subject='Verify your ASI Research Hub account',
            html_content=f"""
            <html>
            <body style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
                <div style="background-color: #f8f9fa; border-radius: 10px; padding: 30px; text-align: center;">
                    <h2 style="color: #2563eb; margin-bottom: 20px;">Welcome to ASI Research Hub, {first_name}!</h2>
                    <p style="color: #4b5563; font-size: 16px; margin-bottom: 30px;">
                        Please verify your email address to access the AI alignment research database.
                    </p>
                    <a href="{verification_url}" 
                       style="display: inline-block; background-color: #2563eb; color: white; 
                              padding: 15px 40px; text-decoration: none; border-radius: 5px; 
                              font-weight: bold; font-size: 16px;">
                        Verify Email Address
                    </a>
                    <p style="color: #6b7280; font-size: 14px; margin-top: 30px;">
                        Or copy and paste this link into your browser:
                    </p>
                    <p style="color: #2563eb; font-size: 12px; word-break: break-all;">
                        {verification_url}
                    </p>
                    <p style="color: #9ca3af; font-size: 12px; margin-top: 30px;">
                        This link will expire in 24 hours.
                    </p>
                </div>
                <div style="text-align: center; margin-top: 30px; padding-top: 20px; border-top: 1px solid #e5e7eb;">
                    <p style="color: #6b7280; font-size: 12px;">
                        ASI Research Hub | Advancing AI Safety Research
                    </p>
                    <p style="color: #9ca3af; font-size: 11px;">
                        If you didn't create this account, please ignore this email.
                    </p>
                </div>
            </body>
            </html>
            """
        )
        
        try:
            if Config.SENDGRID_API_KEY:
                sg = SendGridAPIClient(Config.SENDGRID_API_KEY)
                response = sg.send(message)
                print(f"✅ Verification email sent to {email}")
            else:
                print(f"⚠️ SendGrid not configured. Verification token: {token}")
                print(f"   Verification URL: {verification_url}")
        except Exception as e:
            print(f"❌ Error sending email: {e}")
            print(f"   Verification token for manual use: {token}")
    
    @staticmethod
    def verify_email(token: str) -> dict:
        """Verify user email with token"""
        with get_db() as conn:
            cursor = conn.cursor()
            
            cursor.execute("""
                SELECT id, email FROM users 
                WHERE verification_token = ? AND is_verified = FALSE
            """, (token,))
            
            user = cursor.fetchone()
            
            if not user:
                return {'success': False, 'error': 'Invalid or expired token'}
            
            cursor.execute("""
                UPDATE users 
                SET is_verified = TRUE, verification_token = NULL 
                WHERE id = ?
            """, (user['id'],))
        
        return {'success': True, 'email': user['email']}
    
    @staticmethod
    def login(email: str, password: str) -> dict:
        """Authenticate user and return JWT token"""
        with get_db() as conn:
            cursor = conn.cursor()
            
            cursor.execute("""
                SELECT id, email, password_hash, first_name, last_name, 
                       tier, is_verified 
                FROM users 
                WHERE email = ?
            """, (email,))
            
            user = cursor.fetchone()
            
            if not user:
                return {'success': False, 'error': 'Invalid credentials'}
            
            if not user['is_verified']:
                return {'success': False, 'error': 'Email not verified. Please check your inbox.'}
            
            if not AuthService.verify_password(password, user['password_hash']):
                return {'success': False, 'error': 'Invalid credentials'}
            
            # Update last login
            cursor.execute("""
                UPDATE users SET last_login = CURRENT_TIMESTAMP WHERE id = ?
            """, (user['id'],))
        
        return {
            'success': True,
            'user': {
                'id': user['id'],
                'email': user['email'],
                'first_name': user['first_name'],
                'last_name': user['last_name'],
                'tier': user['tier']
            }
        }
